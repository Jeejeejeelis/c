#include "source.h"

int main()
{
    /* testing exercise 1.8 */
    printf("\n--- Exercise 1.8 ---\n");
    ascii_chart(28,38);
    
    /* testing exercise 1.9 */
    printf("\n--- Exercise 1.9 ---\n");
    secret_msg(0);
    printf("\n");
    secret_msg(1);
        
    /* testing exercise 1.10 */
    printf("\n--- Exercise 1.10 ---\n");
    printf("res: %f\n", calculator());    
        
    return 0;
}
