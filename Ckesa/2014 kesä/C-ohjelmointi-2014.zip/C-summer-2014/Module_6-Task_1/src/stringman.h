#ifndef AALTO_STRINGS_H
#define AALTO_STRINGS_H

void turn_around(char *p);
int is_reversed(const char *p);
void reversed_words(char *p);
int most_common(const char *p, char *result, int size);

#endif
