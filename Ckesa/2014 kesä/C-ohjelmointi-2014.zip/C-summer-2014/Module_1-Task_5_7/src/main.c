#include "source.h"
#include <string.h>

int main()
{
    /* testing exercise 1.5 */
    printf("\n--- Exercise 1.5 ---\n");
    draw_box(4,5); 
    
    /* testing exercise 1.6 */
    printf("\n--- Exercise 1.6 ---\n");
    draw_triangle(5);
    
    /* testing exercise 1.7 */
    printf("\n--- Exercise 1.7 ---\n");
    draw_ball(3);
        
  /*  char a = 10;
    float b = 59387.114;
    char c = 2;
    char* ptr = &a;
    printf("a: %d\n", *ptr);
    ptr = &b;
    printf("b: %f\n", *ptr);
    ptr = &c;
    printf("c: %d\n", *ptr);*/
    
    //printf("Pituus: %lu\n",strlen(""));
    
    /*char c = 40;
    printf("%c",c);*/
    
    return 0;
}