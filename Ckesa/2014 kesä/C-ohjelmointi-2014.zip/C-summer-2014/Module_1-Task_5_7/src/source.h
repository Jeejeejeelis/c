#include <stdio.h>

void draw_box(unsigned int xsize, unsigned int ysize);
void draw_triangle(unsigned int size);
void draw_ball(unsigned int diam);
