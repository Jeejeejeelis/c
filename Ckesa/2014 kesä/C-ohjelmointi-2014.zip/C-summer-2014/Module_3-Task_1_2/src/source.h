#ifndef AALTO_CSUM14_31
#define AALTO_CSUM14_31

int *dyn_reader(unsigned int n);
int *add_to_array(int *arr, unsigned int num, int newval);

#endif
