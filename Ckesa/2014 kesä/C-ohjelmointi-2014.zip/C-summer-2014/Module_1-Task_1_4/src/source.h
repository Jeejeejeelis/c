
void three_lines(void);
double distOrigo(double x, double y);
void simple_sum(void);
float simple_math(void);
