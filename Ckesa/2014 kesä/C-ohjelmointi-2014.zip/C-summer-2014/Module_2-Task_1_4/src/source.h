void number_swap(int *a, int *b);
int array_sum(int *array, int count);
int array_reader(int *vals, int n);
int largest_num(int *start);

