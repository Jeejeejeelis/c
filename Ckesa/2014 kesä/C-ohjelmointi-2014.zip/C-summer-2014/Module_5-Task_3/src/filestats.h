int line_count(const char *filename);
int word_count(const char *filename);
int most_common(const char *filename);
